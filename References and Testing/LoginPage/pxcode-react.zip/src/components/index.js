import Loginscreen from './Loginscreen';

export default { Loginscreen };
